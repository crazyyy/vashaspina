<?php
$this->SET = array(
'last_action' => '0',
'last_db_backup' => 'srv36172_mensview',
'tables' => '',
'comp_method' => '1',
'comp_level' => '7',
'last_db_restore' => '',
'tables_exclude' => '0',
)
?>